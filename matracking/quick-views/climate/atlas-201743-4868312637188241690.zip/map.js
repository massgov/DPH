{
	"template":"Single Map (HTML Edition)",
	"version":"6.8.0_b1,942 (2017-03-02 1454)",
	"boundingBox":"19015.068000000003 768499.5365 345685.632 968849.8735",
	"layers":[
	{
		"type":"base-layer",
		"id":"_Towns_wCCV.shp1",
		"name":"Towns_wCCV.shp",
		"geometry":"polygon",
		"url":"_Towns_wCCV.shp1.js",
		"visible":true,
		"symbolSize":15,
		"fillColor":"#ffffff",
		"fillOpacity":0.8,
		"borderColor":"#cccccc",
		"borderThickness":1,
		"showLabels":false,
		"minLabelExtent":0,
		"maxLabelExtent":1000000,
		"iconPath":"",
		"showDataTips":true,
		"showInLayerList":true
	}
	]
}