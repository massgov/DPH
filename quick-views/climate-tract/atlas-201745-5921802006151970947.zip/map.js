{
	"template":"Single Map (HTML Edition)",
	"version":"6.8.0_b1,942 (2017-03-02 1454)",
	"boundingBox":"19021.244 768403.137 345687.276 968854.663",
	"layers":[
	{
		"type":"base-layer",
		"id":"_Tracts_wCCV.shp1",
		"name":"Tracts_wCCV.shp",
		"geometry":"polygon",
		"url":"_Tracts_wCCV.shp1.js",
		"visible":true,
		"symbolSize":15,
		"fillColor":"#ffffff",
		"fillOpacity":0.8,
		"borderColor":"#cccccc",
		"borderThickness":1,
		"showLabels":false,
		"minLabelExtent":0,
		"maxLabelExtent":1000000,
		"iconPath":"",
		"showDataTips":true,
		"showInLayerList":true
	}
	]
}